# omnio_api

1. install dependencies (npm i)
2. edit data/cs.json and enter the connection string
3. take the file urlencoded.js and place it under node_modules/body_parser/lib/types, replacing the existing file
4. 4. you should now be able to send payloads up to 264 kb
